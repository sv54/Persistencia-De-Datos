//
//  TiempoViewModel.swift
//  ElTiempo_MVVM
//
//  Created by Otto Colomina Pardo on 20/1/22.
//

import Foundation

class TiempoViewModel {
    
}
