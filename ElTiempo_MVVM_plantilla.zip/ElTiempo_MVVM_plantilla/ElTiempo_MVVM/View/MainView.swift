//
//  ViewController.swift
//  ElTiempo_MVVM
//
//

import UIKit

class MainView: UIViewController {

    @IBOutlet weak var estadoLabel: UILabel!
    @IBOutlet weak var estadoImage: UIImageView!
    @IBOutlet weak var campoTexto: UITextField!
    
    @IBAction func botonPulsado(_ sender: Any) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

